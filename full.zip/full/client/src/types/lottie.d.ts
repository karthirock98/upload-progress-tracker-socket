declare module "*.lottie" {
  const value: string;
  export default value;
}
